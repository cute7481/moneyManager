<?php

include $_SERVER['DOCUMENT_ROOT']."../simple_html_dom.php";
//실시간 환율정보
function s_price_baht($type){
 $url = "http://fx.keb.co.kr/FER1101C.web"; //자신이 원하는 페이지
 // get DOM from URL or file
 $html = file_get_html($url);
 
 //날짜
 foreach($html->find('input[type=text]') as $checkbox) {
  if($checkbox->name==iconv("EUC-KR", "UTF-8", "기준일")){
   $insert_date = $checkbox->value;
  }
 }
 $txt_array = array();
 // find all td tags with attribite align=center
 foreach($html->find('table[class=tbl_list_type2]') as $tb_txt){
  //echo $tb_txt->innertext."<br>";
  
  $k = 1;
  foreach($tb_txt->find('tr') as $tr_txt) {
   //echo $tr_txt->innertext."<br>";
   $i = 1;
   foreach($tr_txt->find('td') as $td_txt) {
    $txt_array[$i] = strip_tags($td_txt->innertext);
    if($k=="19" && $i=="10"){
     $insert_thb =  strip_tags($td_txt->innertext);
    }
   $i++;
   }
  $k++;
  }
 }
 if($type=="date"){
  return $insert_date;
 }else if($type=="price"){
  return $insert_thb;
 }
}
 
//echo s_price_baht("date");
echo s_price_baht("price");

?>
