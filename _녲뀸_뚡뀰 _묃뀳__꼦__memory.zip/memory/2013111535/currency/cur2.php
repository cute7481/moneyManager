<?php

$exchange_url="http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.xchange%20where%20pair%20in%20(%22USDKRW%22)&format=json&env=store://datatables.org/alltableswithkeys&callback=";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $exchange_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1000);
$rt = curl_exec($ch);
echo $rt;

curl_close($ch);

?>
