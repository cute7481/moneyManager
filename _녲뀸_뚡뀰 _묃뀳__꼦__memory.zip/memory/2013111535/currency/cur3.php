<?php

$exchange_url="http://download.finance.yahoo.com/d/quotes.csv?s=";
//.$from_currency.$to_currency.'=X&f=sl1d1t1c1ohgv&e=.csv'";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $exchange_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1000);
$rt = curl_exec($ch);
echo $rt;

curl_close($ch);

?>
