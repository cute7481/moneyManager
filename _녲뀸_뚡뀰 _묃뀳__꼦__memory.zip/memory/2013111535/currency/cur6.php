<?php

$exchange_url="http://community.fxkeb.com/fxportal/jsp/RS/DEPLOY_EXRATE/fxrate_all.html"
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $exchange_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1000);
$rt = curl_exec($ch);
curl_close($ch);
echo $rt;

?>
