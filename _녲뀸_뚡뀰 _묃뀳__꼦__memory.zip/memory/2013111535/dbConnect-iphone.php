<?php
$db_hostname = "localhost";
$db_username = "root";
$db_password = "qkrdbswjd";
$dbname = "SWU_project";

$conn = mysqli_connect($db_hostname,$db_username,$db_password,$dbname);
?>
