<?php
header('Content-Type: charset=utf-8');

include_once("../dbConnect-iphone.php");

$message = "";
$userid = ($_POST['id']); 
$frdid = ($_POST['frdid']);
$frdname = ($_POST['frdname']); 
$frdimage = ($_POST['frdimage']);

$sql="insert into friend (userid, frdid, frdname, frdimage) values('$userid','$frdid','$frdname','$frdimage')";

$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

mysqli_close($conn);
?>
