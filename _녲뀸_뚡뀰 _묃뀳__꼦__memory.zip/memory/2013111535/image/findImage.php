<?php

include_once("../dbConnect-iphone.php");

$message = "";
$id = ($_POST['id']);
$sql = "SELECT image FROM W_13_Park_YJ.userimage where userid = '$id'"; 

$query = mysqli_query($conn, $sql) or die(mysqli_error($conn)); 

$row = mysqli_fetch_object($query);

echo $row->image;

mysqli_close($conn);

?>
