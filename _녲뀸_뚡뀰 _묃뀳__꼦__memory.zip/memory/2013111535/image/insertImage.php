<?php

header('Content-Type: charset=utf-8');

include_once("../dbConnect-iphone.php");

$message = "";
$id = ($_POST['id']);
$image = ($_POST['image']);

$sql="insert into W_13_Park_YJ.userimage (userid,image) values('$id','$image')";

$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

mysqli_close($conn);

?>
