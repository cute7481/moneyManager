<?php
include_once("../dbConnect-iphone.php");

$message = "";
$id = ($_POST['id']);

$sql = "SELECT name FROM W_13_Park_YJ.user where userid = '$id'"; 

$query = mysqli_query($conn, $sql) or die(mysqli_error($conn)); 

$row = mysqli_fetch_object($query);

echo $row->name;

mysqli_close($conn);
?>
