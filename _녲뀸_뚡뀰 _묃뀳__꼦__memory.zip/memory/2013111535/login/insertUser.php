<?php
header('Content-Type: charset=utf-8');

include_once("../dbConnect-iphone.php");

$message = "";
$userid = ($_POST['id']); 
$password = ($_POST['password']); 
$name = ($_POST['name']);

$sql="insert into user (userid, passwd, name) values('$userid','$password','$name')";

$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
mysqli_close($conn); 
?>
