<?php
header('Content-type: application/json');

if (isset($_POST['userid'])) {
 include_once("../dbConnect-iphone.php");

// Set the posted data from the form into local variables 
$id = strip_tags($_POST['userid']);
$passwd = strip_tags($_POST['password']);

// 특수문자가 있을 때 Escape 포함한 문자로 변환시켜 SQL Qeury문장의 오류 방지 
$id = mysqli_real_escape_string($conn, $id);
$passwd = mysqli_real_escape_string($conn, $passwd);
$sql = "SELECT userid, passwd FROM W_13_Park_YJ.user WHERE userid = '$id' LIMIT 1"; 
$query = mysqli_query($conn, $sql) or die(mysqli_error($conn));
$row = mysqli_fetch_row($query);
$dbID = $row[0];
$dbPassword = $row[1];

if($id == $dbID && $passwd == $dbPassword) {
echo '{"success":1}'; 
}
else {
echo '{"success":0,"error_message":"ID and/or password is invalid."}'; 
}
}
else {
echo '{"success":0,"error_message":"ID id invalid."}';
}
?>
