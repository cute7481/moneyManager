//
//  CardViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 19..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    NSArray *fArray;
    NSArray *fArray2;
    int csum;
    int ksum;
    NSString *dayCho;
    int inum;
}

@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButton;
@property (strong, nonatomic) IBOutlet UITableView *cardTable;

@property (strong, nonatomic) IBOutlet UILabel *cTotal;
@property (strong, nonatomic) IBOutlet UILabel *cName;
@property (strong, nonatomic) IBOutlet UILabel *kTotal;

@property (strong, nonatomic) IBOutlet UISegmentedControl *segDay;
@property (strong, nonatomic) IBOutlet UILabel *today;

- (IBAction)cgTable:(UISegmentedControl *)sender;

@end
