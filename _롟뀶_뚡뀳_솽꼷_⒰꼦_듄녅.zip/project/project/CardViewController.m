//
//  CardViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 19..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "CardViewController.h"
#import "SWRevealViewController.h"
#import "MoneyData.h"
#import "CardTableViewCell.h"
#import "StartNViewController.h"
#import "DetailMViewController.h"
#import "AppDelegate.h"

@interface CardViewController ()

@end

@implementation CardViewController

@synthesize cardTable;
@synthesize cTotal, cName, kTotal;
@synthesize segDay;

- (void)doTheThing:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    StartNViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"Start"];
    [self presentViewController:start animated:YES
                     completion:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"메뉴"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self.revealViewController
                                                                   action:@selector(revealToggle:)];
    self.tabBarController.navigationItem.rightBarButtonItem = rightButton;
    
    _barButton.target = self.revealViewController;
    _barButton.action = @selector(revealToggle:);
    
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"메인"
                                              style:UIBarButtonItemStylePlain
                                             target:self
                                             action:@selector(doTheThing:)];
    self.tabBarController.navigationItem.leftBarButtonItem = leftButton;
    
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    csum = 0;
    ksum = 0;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.today.text = [dateFormatter stringFromDate:[NSDate date]];
    dayCho = [self.segDay titleForSegmentAtIndex: [self.segDay selectedSegmentIndex]];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    cName.text = app.segcon;
    cTotal.text = @"0";
    kTotal.text = @"0";
    
    fArray = [[NSArray alloc] init];
    [self downloadSData];
}

-(void) downloadSData {
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/money/mTable.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    NSMutableArray *tmpArray = [[NSMutableArray alloc] init];
    NSMutableArray *tmpArray2 = [[NSMutableArray alloc] init];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    NSString *tod = self.today.text;
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        MoneyData *data = [[MoneyData alloc] init];
        data.mnum = jsonElement[@"mnum"];
        data.tnum = jsonElement[@"tnum"];
        data.mcon = jsonElement[@"mcon"];
        data.mday = jsonElement[@"mday"];
        data.mcategory = jsonElement[@"mcategory"];
        data.mway = jsonElement[@"mway"];
        data.mname = jsonElement[@"mname"];
        data.money = jsonElement[@"money"];
        data.mcur = jsonElement[@"mcur"];
        
        if ([data.tnum isEqualToString:app.themeNum]) {
            if ([data.mcon isEqualToString:app.segcon] && [data.mway isEqualToString:@"카드"]) {
                if ([data.mday isEqualToString:tod]) {
                    [tmpArray addObject:data];
                }
                [tmpArray2 addObject:data];
            }
        }
    }
    
    fArray = tmpArray;
    fArray2 = tmpArray2;
    
    [self.cardTable reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.segDay.selectedSegmentIndex == 1) {
        return [fArray2 count];
    }
    else {
        return [fArray count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"CardCell";
    
    CardTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (cell == nil) {
        cell = [[CardTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    MoneyData *md;
    if (self.segDay.selectedSegmentIndex == 1) {
        md = fArray2[indexPath.row];
    }
    else {
        md = fArray[indexPath.row];
    }
    
    cell.cdname.text = md.mname;
    cell.cdmoney.text = md.money;
    cell.cdcountry.text = md.mcon;
    
    if ([md.mcategory isEqualToString:@"쇼핑"]) {
        cell.cdcatimg.image = [UIImage imageNamed:@"shopping.png"];
    }
    else if ([md.mcategory isEqualToString:@"관광"]) {
        cell.cdcatimg.image = [UIImage imageNamed:@"travel.png"];
    }
    else if ([md.mcategory isEqualToString:@"교통"]) {
        cell.cdcatimg.image = [UIImage imageNamed:@"transport.png"];
    }
    else if ([md.mcategory isEqualToString:@"음식"]) {
        cell.cdcatimg.image = [UIImage imageNamed:@"food.png"];
    }
    else if ([md.mcategory isEqualToString:@"숙박"]) {
        cell.cdcatimg.image = [UIImage imageNamed:@"lodge.png"];
    }
    else if ([md.mcategory isEqualToString:@"기타"]) {
        cell.cdcatimg.image = [UIImage imageNamed:@"guitar.png"];
    }
    
    float m = [md.money floatValue];
    float c = [md.mcur floatValue];
    
    csum = csum + m;
    
    int sum = m*c;
    ksum = ksum + sum;
    
    kTotal.text = [NSString stringWithFormat:@"%i", ksum];
    cTotal.text = [NSString stringWithFormat:@"%i", csum];
    
    return cell;
}

- (IBAction)cgTable:(UISegmentedControl *)sender {
    switch (self.segDay.selectedSegmentIndex) {
        case 0:
            inum = 0;
            
            csum = 0;
            ksum = 0;
            cTotal.text = @"0";
            kTotal.text = @"0";
            
            [self.cardTable reloadData];
            NSLog(@"success");
            
            break;
        case 1:
            inum = 1;
            
            csum = 0;
            ksum = 0;
            cTotal.text = @"0";
            kTotal.text = @"0";
            
            [self.cardTable reloadData];
            NSLog(@"success");
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"CardDetail"]) {
        DetailMViewController *detailVC = segue.destinationViewController;
        NSIndexPath *indexPath = [self.cardTable indexPathForSelectedRow];
        
        MoneyData *item;
        if (self.segDay.selectedSegmentIndex == 1) {
            item = fArray2[indexPath.row];
        }
        else {
            item = fArray[indexPath.row];
        }
        
        detailVC.title = item.mname;
        detailVC.pickData = item;
    }
}

@end
