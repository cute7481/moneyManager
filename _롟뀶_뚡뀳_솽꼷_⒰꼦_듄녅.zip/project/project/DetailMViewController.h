//
//  DetailMViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 4..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MoneyData.h"

@interface DetailMViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *dDate;
@property (strong, nonatomic) IBOutlet UILabel *dCategory;
@property (strong, nonatomic) IBOutlet UILabel *dName;
@property (strong, nonatomic) IBOutlet UILabel *dMoney;
@property (strong, nonatomic) IBOutlet UILabel *dCountry;
@property (strong, nonatomic) IBOutlet UILabel *dCurrency;
@property (strong, nonatomic) IBOutlet UILabel *dKorea;

@property (strong, nonatomic) MoneyData *pickData;

- (IBAction)btnDelete:(UIButton *)sender;


@end
