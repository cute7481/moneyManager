//
//  FirstViewController.h
//  CHART2
//
//  Created by SWUcomouter on 2016. 6. 4..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//

#import <UIKit/UIKit.h>



#import <UIKit/UIKit.h>
#import "SimpleBarChart.h"

@interface FirstViewController : UIViewController <SimpleBarChartDataSource, SimpleBarChartDelegate> {
    NSArray *_values;
    NSArray *_category;
    
    NSInteger max;
    
    SimpleBarChart *_chart;
    
    NSArray *_barColors;
    NSInteger _currentBarColor;
    NSInteger _maxBarColor;
    
    float shop;
    float tour;
    float traf;
    float food;
    float lodge;
    float etc;
}

@property (strong, nonatomic) IBOutlet UILabel *setDate;
@property (strong, nonatomic) IBOutlet UIDatePicker *pDate;
@property (strong, nonatomic) IBOutlet UILabel *country;

- (IBAction)dateChanged:(UIDatePicker *)sender;

- (IBAction)dpickerShow:(UIButton *)sender;

- (IBAction)totalShow:(UIButton *)sender;

@end
