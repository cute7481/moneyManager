//
//  InsertCViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "InsertCViewController.h"
#import "CountryViewController.h"
#import "AppDelegate.h"

@interface InsertCViewController ()

@end

@implementation InsertCViewController

@synthesize country;
@synthesize conPicker, datePicker;
@synthesize dateS, dateF;
@synthesize cashCur;

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void) viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    CountryViewController *countryVC;
    [countryVC.conCollection reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    aryCon = [[NSArray alloc] initWithObjects:
              @"미국 USD", @"일본 JPY", @"유럽연합 EUR", @"중국 CNY", @"영국 GBP",
              @"스위스 CHF", @"캐나다 CAD", @"호주 AUD", @"뉴질랜드 NZD", @"홍콩 HKD",
              @"스웨덴 SEK", @"덴마크 DKK", @"노르웨이 NOK", @"사우디 SAR", @"쿠웨이트 KWD",
              @"바레인 BHD", @"아랍연방 AED", @"태국 THB", @"싱가포르 SGD", @"인도네시아 IDR",
              @"인도 INR", @"말레이지아 MYR", nil];
    
    aryCImg = [[NSArray alloc] initWithObjects:
             @"United States Flag.png", @"Japan Flag.png", @"European Union flag.jpg", @"China Flag.png", @"United Kingdom flag.png",
             @"Switzerlandflag.png", @"Canada Flag.png", @"Australia Flag.png", @"New Zealand Flag.png", @"Hong Kong Flag.png",
             @"Swedenflag.png", @"Denmark flag.png", @"Norway Flag.png", @"Saudi Arabian flag.jpg", @"Kuwait flag.png",
             @"Bahrain flag.png", @"United Arab Emirates flag.png", @"Thailandflag.png", @"Singapore Flag.png", @"Indonesia flag.png",
             @"India Flag.png", @"Malaysia Flag.png", nil];
}

//국가 선택
- (IBAction)selectCountry:(UIButton *)sender {
    self.country.text = [aryCon objectAtIndex:[self.conPicker selectedRowInComponent: 0]];
    matchImg = [aryCImg objectAtIndex:[self.conPicker selectedRowInComponent:0]];
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [aryCon count];
}

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [aryCon objectAtIndex:row];
}

//alert
- (void) alertStatus:(NSString *)msg :(NSString *)title {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [alertView show];
}


- (IBAction)startdSelected:(UIButton *)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.dateS.text = [dateFormatter stringFromDate: self.datePicker.date];
}

- (IBAction)finishdSelected:(UIButton *)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.dateF.text = [dateFormatter stringFromDate: self.datePicker.date];
}

- (IBAction)saveCountry:(UIBarButtonItem *)sender {
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    //NSString *tnum = app.themeNum;
    NSString *cstartd = self.dateS.text;
    NSString *cfinishd = self.dateF.text;
    NSString *ccountry = self.country.text;
    NSString *ccur = self.cashCur.text;
    
    if ([ccountry isEqualToString:@""]) {
        [self alertStatus:@"국가를 선택해주세요." :@"저장 실패!"];
    }
    else if ([cstartd isEqualToString:@""] || [cfinishd isEqualToString:@""]) {
        [self alertStatus:@"기간을 설정해주세요." :@"저장 실패!"];
    }
    else {
        NSString *rawStr = [NSString stringWithFormat: @"tnum=%@&cstartd=%@&cfinishd=%@&ccountry=%@&ccur=%@&cflag=%@",
                            app.themeNum, cstartd, cfinishd, ccountry, ccur, matchImg];
        
        NSData *data = [rawStr dataUsingEncoding:NSUTF8StringEncoding];
        
        NSURL *url = [NSURL URLWithString:@"http://localhost/~swucomputer/country/insertCountry.php"];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:data];
        
        NSURLResponse *response;
        NSError *err;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request
                                                     returningResponse:&response
                                                                 error:&err];
        NSString *responseString =[NSString stringWithUTF8String:[responseData bytes]];
        NSLog(@"%@", responseString);
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
