//
//  InsertTViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InsertTViewController : UIViewController <UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (strong, nonatomic) IBOutlet UITextField *textName;

@property (strong, nonatomic) IBOutlet UIImageView *usrimg;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UILabel *startdate;
@property (strong, nonatomic) IBOutlet UILabel *finishdate;

- (IBAction)startPick:(UIButton *)sender;
- (IBAction)finishPick:(UIButton *)sender;

- (IBAction)takePicture:(UIButton *)sender;
- (IBAction)selectPicture:(UIButton *)sender;

- (IBAction)saveTheme:(UIBarButtonItem *)sender;

- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end
