//
//  InsertTViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "InsertTViewController.h"
#import "ThemeViewController.h"

@interface InsertTViewController ()

@end

@implementation InsertTViewController

@synthesize textName;
@synthesize usrimg;
@synthesize datePicker;
@synthesize startdate, finishdate;

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void) viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    ThemeViewController *themeVC;
    [themeVC.myCollectionView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

//alert
- (void) alertStatus:(NSString *)msg :(NSString *)title {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [alertView show];
}

//image
- (IBAction)selectPicture:(UIButton *)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    //UIImage *chosenImage = [info objectForKey:UIImagePickerControllerEditedImage];
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.usrimg.image = chosenImage;
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction) takePicture:(UIButton *)sender {
    if (![UIImagePickerController
          isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        [myAlertView show];
    }
    else {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:NULL];
    }
}

- (IBAction)startPick:(UIButton *)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //[dateFormatter setTimeStyle: NSDateFormatterShortStyle];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.startdate.text = [dateFormatter stringFromDate: self.datePicker.date];
}

- (IBAction)finishPick:(UIButton *)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //[dateFormatter setTimeStyle: NSDateFormatterShortStyle];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.finishdate.text = [dateFormatter stringFromDate: self.datePicker.date];
}

- (IBAction)saveTheme:(UIBarButtonItem *)sender {
    NSString *tstartd = self.startdate.text;
    NSString *tfinishd = self.finishdate.text;
    UIImage *timage = self.usrimg.image;
    NSString *imageRoute;
    NSString *tname = self.textName.text;
    
    if ([tname isEqualToString:@""]) {
        [self alertStatus:@"내용을 입력하세요." :@"저장 실패!"];
    }
    else if ([tstartd isEqualToString:@""] || [tfinishd isEqualToString:@""]) {
        [self alertStatus:@"기간을 설정해주세요." :@"저장 실패!"];
    }
    else {
        if (timage != nil) { //이미지 업로드
            NSData *imageData = UIImageJPEGRepresentation(timage, 0.9);
            
            NSString *urlString = @"http://localhost/~swucomputer/theme/image/upload.php";
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
            
            [request setURL:[NSURL URLWithString:urlString]];
            [request setHTTPMethod:@"POST"];
            
            NSString *boundary = @"---------------------------14737809831466499882746641449";
            NSString *contentType = [NSString stringWithFormat:
                                     @"multipart/form-data; boundary=%@", boundary];
            [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
            
            NSMutableData *body = [NSMutableData data];
            [body appendData:[ [NSString stringWithFormat:@"\r\n--%@\r\n", boundary]
                              dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[@"Content-Disposition: form-data; name=\"userfile\"; filename=\".jpg\"\r\n"
                              dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n"
                              dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[NSData dataWithData:imageData]];
            [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary]
                              dataUsingEncoding:NSUTF8StringEncoding]];
            [request setHTTPBody:body];
            
            NSData *returnData = [NSURLConnection sendSynchronousRequest:request
                                                       returningResponse:nil error:nil];
            imageRoute = [[NSString alloc] initWithData:returnData
                                               encoding:NSUTF8StringEncoding];
        }
        //DB저장
        NSString *rawStr = [NSString stringWithFormat: @"tstartd=%@&tfinishd=%@&timage=%@&tname=%@",
                            tstartd, tfinishd, imageRoute, tname];
        
        NSData *data = [rawStr dataUsingEncoding:NSUTF8StringEncoding];
        
        NSURL *url = [NSURL URLWithString:@"http://localhost/~swucomputer/theme/insertTheme.php"];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:data];
        
        NSURLResponse *response;
        NSError *err;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request
                                                     returningResponse:&response
                                                                 error:&err];
        NSString *responseString =[NSString stringWithUTF8String:[responseData bytes]];
        NSLog(@"%@", responseString);
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
