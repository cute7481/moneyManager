//
//  LodgeTableViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 3..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LodgeTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lname;
@property (strong, nonatomic) IBOutlet UILabel *lmoney;
@property (strong, nonatomic) IBOutlet UILabel *lcountry;

@property (strong, nonatomic) IBOutlet UIImageView *cimg;

@end
