//
//  RTCurViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 20..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RTCurViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
    UIImage *Korea;
    UIImage *Australia;
    UIImage *Canada;
    UIImage *China;
    //UIImage *France;
    //UIImage *Germany;
    UIImage *HongKong;
    UIImage *India;
    //UIImage *Ireland;
    //UIImage *Italy;
    UIImage *Japan;
    UIImage *Malaysia;
    UIImage *NewZealand;
    UIImage *Norway;
    //UIImage *Philippines;
    UIImage *Singapore;
    //UIImage *Spain;
    UIImage *Sweden;
    UIImage *Switzerland;
    //UIImage *Taiwan;
    UIImage *Thailand;
    //UIImage *Turkey;
    UIImage *UnitedKingdom;
    UIImage *UnitedStates;
    //UIImage *Vietnam;
    UIImage *EuropeanUnion;
    UIImage *Denmark;
    UIImage *SaudiArabian;
    UIImage *Kuwait;
    UIImage *Bahrain;
    UIImage *UnitedArabEmirates;
    UIImage *Indonesia;
}

@property (strong, nonatomic) IBOutlet UILabel *refDate;
@property (strong, nonatomic) IBOutlet UITableView *curTable;

- (IBAction)refreshTable:(UIButton *)sender;

@end
