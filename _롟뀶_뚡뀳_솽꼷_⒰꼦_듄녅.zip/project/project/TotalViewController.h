//
//  TotalViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 12..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TotalViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    NSArray *fArray;
    NSArray *fArray2;
    int csum;
    int ksum;
    NSString *dayCho;
    int inum;
}

@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButton;

@property (strong, nonatomic) IBOutlet UITableView *totalTable;

@property (strong, nonatomic) IBOutlet UILabel *cTotal;
@property (strong, nonatomic) IBOutlet UILabel *cName;
@property (strong, nonatomic) IBOutlet UILabel *kTotal;

@property (strong, nonatomic) IBOutlet UISegmentedControl *segDay;
@property (strong, nonatomic) IBOutlet UILabel *today;

- (IBAction)cgTable:(UISegmentedControl *)sender;

@property (strong, nonatomic) IBOutlet UITabBarItem *totalTab;

@end
