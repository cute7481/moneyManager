//
//  BicmViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 20..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BicmViewController : UIViewController
        <UIPickerViewDataSource,UIPickerViewDelegate> {
    UIImage *Korea;
    UIImage *Australia;
    UIImage *Canada;
    UIImage *China;
    UIImage *France;
    UIImage *Germany;
    UIImage *HongKong;
    UIImage *India;
    UIImage *Ireland;
    UIImage *Italy;
    UIImage *Japan;
    UIImage *Malaysia;
    UIImage *NewZealand;
    UIImage *Norway;
    UIImage *Philippines;
    UIImage *Singapore;
    UIImage *Spain;
    UIImage *Sweden;
    UIImage *Switzerland;
    UIImage *Taiwan;
    UIImage *Thailand;
    UIImage *Turkey;
    UIImage *UnitedKingdom;
    UIImage *UnitedStates;
    UIImage *Vietnam;

    NSArray * data1; // 국가 이름
    NSArray * data2; // 빅맥 지수
}

@property (strong, nonatomic) IBOutlet UIImageView *koreaflag;
@property (strong, nonatomic) IBOutlet UIImageView *nationflag;

@property (strong, nonatomic) IBOutlet UILabel *nation;
@property (strong, nonatomic) IBOutlet UILabel *bigmac;

@property (strong, nonatomic) IBOutlet UIPickerView *picker;

- (IBAction)getValue;

@end
