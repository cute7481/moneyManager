//
//  BicmViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 20..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "BicmViewController.h"

@interface BicmViewController ()

@end

@implementation BicmViewController

@synthesize picker;
@synthesize nation, bigmac;
@synthesize koreaflag, nationflag;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    picker.transform = CGAffineTransformMake(0.85, 0, 0, 0.8, 0, 0);
    self.tabBarController.tabBar.barTintColor = [UIColor colorWithRed:153.0/225.0 green:160 blue:0 alpha:1];
    
    data1 = [[NSArray alloc] initWithObjects:
             @"Australia", @"Canada", @"China", @"France", @"Germany",
             @"Hongkong", @"India", @"Ireland", @"Italy", @"Japan",
             @"Korea", @"Malaysia", @"NewZealand", @"Norway", @"Philippines",
             @"Singapore", @"Spain", @"Sweden", @"Switzerland", @"Taiwan",
             @"Thailand", @"Turkey", @"UnitedKingdom", @"UnitedStates", @"Vietnam", nil];
    data2 = [[NSArray alloc]initWithObjects:
             @"3.74 $", @"4.14 $", @"2.68 $", @"4.00 $", @"4.00 $",
             @"2.48 $", @"1.90 $", @"4.00 $", @"4.00 $", @"3.12 $",
             @"3.59 $", @"1.82 $", @"3.91 $", @"5.21 $", @"2.79 $",
             @"3.27 $", @"4.00 $", @"5.23 $", @"6.44 $", @"2.08 $",
             @"3.09 $", @"3.41 $", @"4.22 $", @"4.93 $", @"2.67 $", nil];
    
    Korea = [UIImage imageNamed:@"Korea Flag.png"];
    [koreaflag setImage:Korea];//default
    
    Canada = [UIImage imageNamed:@"Canada Flag.png"];
    Australia = [UIImage imageNamed:@"Australia Flag.png"];
    China = [UIImage imageNamed:@"China Flag.png"];
    France = [UIImage imageNamed:@"France Flag.png"];
    Germany = [UIImage imageNamed:@"Germany Flag.png"];
    HongKong = [UIImage imageNamed:@"Hong Kong Flag.png"];
    India = [UIImage imageNamed:@"India Flag.png"];
    Ireland = [UIImage imageNamed:@"Ireland Flag.png"];
    Italy = [UIImage imageNamed:@"Italy Flag.png"];
    Japan  = [UIImage imageNamed:@"Japan Flag.png"];
    Malaysia = [UIImage imageNamed:@"Malaysia Flag.png"];
    NewZealand = [UIImage imageNamed:@"New Zealand Flag.png"];
    Norway = [UIImage imageNamed:@"Norway Flag.png"];
    Philippines = [UIImage imageNamed:@"Philippines Flag.png"];
    Singapore = [UIImage imageNamed:@"Singapore Flag.png"];
    Spain = [UIImage imageNamed:@"Spain Flag.png"];
    Sweden = [UIImage imageNamed:@"Swedenflag.png"];
    Switzerland = [UIImage imageNamed:@"Switzerlandflag.png"];
    Taiwan = [UIImage imageNamed:@"Taiwan Flag.png"];
    Thailand = [UIImage imageNamed:@"Thailandflag.png"];
    Turkey = [UIImage imageNamed:@"Turkey Flag.png"];
    UnitedKingdom = [UIImage imageNamed:@"United Kingdom flag.png"];
    UnitedStates = [UIImage imageNamed:@"United States Flag.png"];
    Vietnam = [UIImage imageNamed:@"Vietnam Flag.png"];
}

- (IBAction)getValue {
    NSString *first = [data1 objectAtIndex:[self.picker selectedRowInComponent: 0]];
    self.nation.text = [first stringByAppendingFormat:@" "];
    
    NSString *second =[data2 objectAtIndex:[self.picker selectedRowInComponent: 0]];
    self.bigmac.text = [second stringByAppendingFormat:@" "];
    
    if([first isEqual:@"Canada"])
        [nationflag setImage:Canada];
    else if([first isEqual:@"Australia"])
        [nationflag setImage:Australia];
    else if ([first isEqual:@"China"])
        [nationflag setImage:China];
    else if ([first isEqual:@"France"])
        [nationflag setImage:France];
    else if ([first isEqual:@"Germany"])
        [nationflag setImage:Germany];
    else if ([first isEqual:@"Hongkong"])
        [nationflag setImage:HongKong];
    else if ([first isEqual:@"India"])
        [nationflag setImage:India];
    else if ([first isEqual:@"Ireland"])
        [nationflag setImage:Ireland];
    else if ([first isEqual:@"Italy"])
        [nationflag setImage:Italy];
    else if ([first isEqual:@"Japan"])
        [nationflag setImage:Japan];
    else if ([first isEqual:@"Malaysia"])
        [nationflag setImage:Malaysia];
    else if ([first isEqual:@"NewZealand"])
        [nationflag setImage:NewZealand];
    else if ([first isEqual:@"Norway"])
        [nationflag setImage:Norway];
    else if ([first isEqual:@"Philippines"])
        [nationflag setImage:Philippines];
    else if ([first isEqual:@"Singapore"])
        [nationflag setImage:Singapore];
    else if ([first isEqual:@"Spain"])
        [nationflag setImage:Spain];
    else if ([first isEqual:@"Sweden"])
        [nationflag setImage:Sweden];
    else if ([first isEqual:@"Switzerland"])
        [nationflag setImage:Switzerland];
    else if ([first isEqual:@"Taiwan"])
        [nationflag setImage:Taiwan];
    else if ([first isEqual:@"Thailand"])
        [nationflag setImage:Thailand];
    else if ([first isEqual:@"Turkey"])
        [nationflag setImage:Turkey];
    else if ([first isEqual:@"UnitedKingdom"])
        [nationflag setImage:UnitedKingdom];
    else if ([first isEqual:@"UnitedStates"])
        [nationflag setImage:UnitedStates];
    else if ([first isEqual:@"Vietnam"])
        [nationflag setImage:Vietnam];
    else
        [nationflag setImage:Korea];
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [data1 count];
}

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [data1 objectAtIndex:row];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
