//
//  CountryCollectionViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CountryCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *conImg;

@property (strong, nonatomic) IBOutlet UILabel *country;
@property (strong, nonatomic) IBOutlet UILabel *cdate;
@property (strong, nonatomic) IBOutlet UILabel *cfdate;


@end
