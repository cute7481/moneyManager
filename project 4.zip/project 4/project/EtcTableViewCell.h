//
//  EtcTableViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 3..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EtcTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *ename;
@property (strong, nonatomic) IBOutlet UILabel *emoney;
@property (strong, nonatomic) IBOutlet UILabel *ecountry;

@property (strong, nonatomic) IBOutlet UIImageView *cimg;

@end
