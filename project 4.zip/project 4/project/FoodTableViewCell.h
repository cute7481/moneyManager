//
//  FoodTableViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 3..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *fname;
@property (strong, nonatomic) IBOutlet UILabel *fmoney;
@property (strong, nonatomic) IBOutlet UILabel *fcountry;

@property (strong, nonatomic) IBOutlet UIImageView *cimg;

@end
