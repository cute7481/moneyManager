//
//  InsertCViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InsertCViewController : UIViewController
    <UITextFieldDelegate, UIPickerViewDataSource, UIPickerViewDelegate> {
        NSArray *aryCon;
        NSArray *aryCImg;
        NSString *matchImg;
}


@property (strong, nonatomic) IBOutlet UILabel *country;
@property (strong, nonatomic) IBOutlet UIPickerView *conPicker;

@property (strong, nonatomic) IBOutlet UIDatePicker *datePicker;
@property (strong, nonatomic) IBOutlet UILabel *dateS;
@property (strong, nonatomic) IBOutlet UILabel *dateF;

@property (strong, nonatomic) IBOutlet UITextField *cashCur;

- (IBAction)selectCountry:(UIButton *)sender;

- (IBAction)startdSelected:(UIButton *)sender;
- (IBAction)finishdSelected:(UIButton *)sender;

- (IBAction)saveCountry:(UIBarButtonItem *)sender;

- (BOOL)textFieldShouldReturn:(UITextField *)textField;

@end
