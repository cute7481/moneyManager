//
//  InsertMViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "InsertMViewController.h"
#import "TotalViewController.h"
#import "AppDelegate.h"
#import "SWRevealViewController.h"

@interface InsertMViewController ()

@end

@implementation InsertMViewController {
    NSString *segcat;
    NSString *segw;
}

@synthesize mdate;
@synthesize mName, spendM, mcurText;
@synthesize segCat, segCC;
@synthesize whatcur;
@synthesize writeCurV;
@synthesize moneyCur;

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void)doTheThing:(id)sender {
    NSLog(@"start");
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    //NSString *tnum = app.themeNum;
    //NSString *mcon = app.segcon;
    NSString *mday = mdate.text;
    NSString *mcategory = segcat;
    NSString *mway = segw;
    NSString *mname = mName.text;
    NSString *money = spendM.text;
    NSString *mcur = moneyCur.text;
    
    if ([mname isEqualToString:@""] || [money isEqualToString:@""] || [mcur isEqualToString:@""]) {
        [self alertStatus:@"모두 작성해주세요." :@"저장 실패!"];
    }
    else if ([mcategory isEqualToString:@""] || [mway isEqualToString:@""]) {
        [self alertStatus:@"목록을 선택해주세요." :@"저장 실패!"];
    }
    
    else {
        NSString *rawStr = [NSString stringWithFormat: @"tnum=%@&mcon=%@&mday=%@&mcategory=%@&mway=%@&mname=%@&money=%@&mcur=%@",
                            app.themeNum, app.segcon, mday, mcategory, mway, mname, money, mcur];
        
        NSData *data = [rawStr dataUsingEncoding:NSUTF8StringEncoding];
        
        NSURL *url = [NSURL URLWithString:@"http://localhost/~swucomputer/money/insertMoney.php"];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
        
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:data];
        
        NSURLResponse *response;
        NSError *err;
        
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request
                                                     returningResponse:&response
                                                                 error:&err];
        NSString *responseString =[NSString stringWithUTF8String:[responseData bytes]];
        
        NSLog(@"%@", responseString);
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *start = [storyboard
                                       instantiateViewControllerWithIdentifier:@"RevealView"];
        [self presentViewController:start animated:YES
                         completion:nil];
    }
}

- (void)doTheThing2:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SWRevealViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"RevealView"];
    [self presentViewController:start animated:YES
                     completion:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
        
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"저장"
                                                                    style:UIBarButtonItemStylePlain
                                                                    target:self
                                                                    action:@selector(doTheThing:)];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"취소"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(doTheThing2:)];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    segw = @"현금";
    segcat = @"음식";
    
    [self.writeCurV setHidden:YES];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.mdate.text = [dateFormatter stringFromDate:[NSDate date]];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    whatcur.text = app.segcon;
}

- (void) viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    TotalViewController *totalVC;
    [totalVC.totalTable reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    if ([app.segcon isEqualToString:@"USD"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"JPY"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"EUR"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"CNY"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"GBP"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"CAD"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"AUD"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"NZD"]) {
        whatcur.text = @"$";
    }
    else if ([app.segcon isEqualToString:@"HKD"]) {
        app.segcon = @"HKD";
    }
    else if ([app.segcon isEqualToString:@"SEK"]) {
        app.segcon = @"SEK";
    }
    else if ([app.segcon isEqualToString:@"DKK"]) {
        app.segcon = @"DKK";
    }
    else if ([app.segcon isEqualToString:@"NOK"]) {
        app.segcon = @"NOK";
    }
    else if ([app.segcon isEqualToString:@"SAR"]) {
        app.segcon = @"SAR";
    }
    else if ([app.segcon isEqualToString:@"KWD"]) {
        app.segcon = @"KWD";
    }
    else if ([app.segcon isEqualToString:@"BHD"]) {
        app.segcon = @"BHD";
    }
    else if ([app.segcon isEqualToString:@"AED"]) {
        app.segcon = @"AED";
    }
    else if ([app.segcon isEqualToString:@"THB"]) {
        app.segcon = @"THB";
    }
    else if ([app.segcon isEqualToString:@"SGD"]) {
        app.segcon = @"SGD";
    }
    else if ([app.segcon isEqualToString:@"IDR"]) {
        app.segcon = @"IDR";
    }
    else if ([app.segcon isEqualToString:@"INR"]) {
        app.segcon = @"INR";
    }
    else if ([app.segcon isEqualToString:@"MYR"]) {
        app.segcon = @"MYR";
    }
    */
}

- (void) alertStatus:(NSString *)msg :(NSString *)title {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [alertView show];
}

- (IBAction)mdateChange:(UIButton *)sender {
    //[NSDate date];
    //mdate.text = [NSDate date];
}

- (IBAction)categorySet:(UISegmentedControl *)sender {
    segcat = [sender titleForSegmentAtIndex:[sender selectedSegmentIndex]];
}

- (IBAction)waySet:(UISegmentedControl *)sender {
    segw = [sender titleForSegmentAtIndex:[sender selectedSegmentIndex]];
}

- (IBAction)mcashCur:(UIButton *)sender {
    //사용자가 이전에 저장한 환전 환율 가져오기
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    moneyCur.text = app.cashc;
}

- (IBAction)mcardCur:(UIButton *)sender {
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    NSLog(@"%@",app.segcon);
    //실시간 환율 가져오기
    NSString *add = [app.segcon stringByAppendingString:@".php"];
    NSString *adr = @"http://localhost/~swucomputer/cur/";
    NSString *gUrl = [adr stringByAppendingString: add];
    
    NSString *message;
    NSURL *urlString = [NSURL URLWithString:gUrl];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:urlString];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSError *err = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:urlRequest
                                                 returningResponse:&response
                                                             error:&err];
    NSString *responseString = [[NSString alloc] initWithBytes:[responseData bytes]
                                                        length:[responseData length]
                                                      encoding:NSUTF8StringEncoding];
    message = responseString;
    
    moneyCur.text = message;
}

- (IBAction)mwriteCur:(UIButton *)sender {
    [self.writeCurV setHidden:NO];
}

- (IBAction)mwfinish:(UIButton *)sender {
    if (mcurText != nil) {
        moneyCur.text = mcurText.text;
        [self.writeCurV setHidden:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"toReveal"]) {
        [self.navigationController setNavigationBarHidden:YES animated:YES];
    }
}

@end
