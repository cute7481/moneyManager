//
//  NSMutableArray+TTMutableArray.h
//  TypeTeacher
//
//  Created by Mohammed Islam on 11/18/13.
//  Copyright (c) 2013 KSITechnology. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (TTMutableArray)

- (void)shuffle;

@end
