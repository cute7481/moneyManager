//
//  ThemeCollectionViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *themeImg;

@property (strong, nonatomic) IBOutlet UILabel *theme;
@property (strong, nonatomic) IBOutlet UILabel *themeDate;

@end
