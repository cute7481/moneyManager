//
//  ThemeData.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThemeData : NSObject

@property (nonatomic, strong) NSString *tnum;
@property (nonatomic, strong) NSString *tstartd;
@property (nonatomic, strong) NSString *tfinishd;
@property (nonatomic, strong) NSString *timage;
@property (nonatomic, strong) NSString *tname;

@end
