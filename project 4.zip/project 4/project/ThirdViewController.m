//
//  ThirdViewController.m
//  CHART2
//
//  Created by SWUcomouter on 2016. 6. 4..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//

#import "ThirdViewController.h"
#import "MoneyData.h"
#import "AppDelegate.h"
#import "SWRevealViewController.h"
#import "StartNViewController.h"

#define OFFSET 20

@interface ThirdViewController ()

@end

@implementation ThirdViewController

@synthesize pieChartView;
@synthesize scroll;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    values = [[NSArray alloc] init];
    labels = [[NSArray alloc] initWithObjects:@"현금", @"카드", nil];
    
    ccolors = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < labels.count; i++) {
        CGFloat hue = ( arc4random() % 256 / 256.0 );  //  0.0 to 1.0
        CGFloat saturation = ( arc4random() % 128 / 256.0 ) + 0.5;  //  0.5 to 1.0, away from white
        CGFloat brightness = ( arc4random() % 128 / 256.0 ) + 0.5;  //  0.5 to 1.0, away from black
        UIColor *rand = [UIColor colorWithHue:hue saturation:saturation brightness:brightness alpha:1];
        
        [ccolors addObject:rand];
    }
    
    self.pieChartView.dataSource = self;
    self.pieChartView.delegate = self;
    self.pieChartView.animationDuration = 0.5;
    self.pieChartView.sliceColor = [MCUtil flatWetAsphaltColor];
    self.pieChartView.borderColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.selectedSliceColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.textColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.selectedTextColor = [MCUtil flatWetAsphaltColor];
    self.pieChartView.borderPercentage = 0.02; // 슬라이스 두께
}

- (void)legendClicked:(id)sender {
    //NSString *btnSelect = lbl.text; // = [NSString stringWithFormat:@"%@",[values objectAtIndex:]];
}

- (void)makelabels {
    
    CGFloat legendX,legendY,legendWidth, legendHeight;
    
    legendX = OFFSET*2;
    legendY = OFFSET*18;
    legendWidth = 500;
    legendHeight = 500 - OFFSET;
    
    int y = 5;
    for (int i = 0;i < values.count;i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
     
        btn.frame = CGRectMake(5, y, 30, 30);
        btn.tag = i;
        [btn addTarget:self action:@selector(legendClicked:) forControlEvents:UIControlEventTouchUpInside];
        btn.backgroundColor = [ccolors objectAtIndex:i];
        
        [scroll addSubview:btn];
        
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(40, y, legendWidth-OFFSET*2, 30)];
        
        lbl.text = [NSString stringWithFormat:@"%@",[labels objectAtIndex:i]];
        lbl.backgroundColor = [UIColor clearColor];
        [lbl setAdjustsFontSizeToFitWidth:YES];

        [scroll addSubview:lbl];
        
        y += lbl.frame.size.height+5;
    }
}

- (void)doTheThing:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    StartNViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"Start"];
    [self presentViewController:start animated:YES
                     completion:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"메뉴"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self.revealViewController
                                                                   action:@selector(revealToggle:)];
    
    self.tabBarController.navigationItem.rightBarButtonItem = rightButton;
    
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"메인"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(doTheThing:)];
    self.tabBarController.navigationItem.leftBarButtonItem = leftButton;
    
    
    values = [[NSArray alloc] init];
    
    cardSum = 0;
    cashSum = 0;
    
    [self downloadSData];
    
    [self makelabels];
}

-(void) downloadSData {
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/money/mTable.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        MoneyData *data = [[MoneyData alloc] init];
        data.mnum = jsonElement[@"mnum"];
        data.tnum = jsonElement[@"tnum"];
        data.mcon = jsonElement[@"mcon"];
        data.mday = jsonElement[@"mday"];
        data.mcategory = jsonElement[@"mcategory"];
        data.mway = jsonElement[@"mway"];
        data.mname = jsonElement[@"mname"];
        data.money = jsonElement[@"money"];
        data.mcur = jsonElement[@"mcur"];
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];
        
        if ([data.mcon isEqualToString:app.segcon]) {
            if ([data.mway isEqualToString:@"현금"]) {
                cashSum = cashSum + [data.money floatValue];
            }
            else if ([data.mway isEqualToString:@"카드"]) {
                cardSum = cardSum + [data.money floatValue];
            }
        }
    }
    
    NSArray *totAry = [[NSArray alloc]initWithObjects:[NSNumber numberWithInt:cashSum],
                       [NSNumber numberWithInt:cardSum], nil];
    
    values = totAry;
    
    [self.pieChartView reloadData];
}

- (UIColor *)pieChartView:(MCPieChartView *)pieChartView colorForSliceAtIndex:(NSInteger)index {
    return [ccolors objectAtIndex:index];
}

- (NSInteger)numberOfSlicesInPieChartView:(MCPieChartView *)pieChartView {
    return [values count];
}

- (CGFloat)pieChartView:(MCPieChartView *)pieChartView valueForSliceAtIndex:(NSInteger)index {
    return [[values objectAtIndex:index] floatValue];
}

- (UIColor*)pieChartView:(MCPieChartView *)pieChartView colorForTextAtIndex:(NSInteger)index {
    return [UIColor whiteColor];
}


@end
