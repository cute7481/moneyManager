//
//  TourTableViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 3..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TourTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *toname;
@property (strong, nonatomic) IBOutlet UILabel *tomoney;
@property (strong, nonatomic) IBOutlet UILabel *tocountry;

@property (strong, nonatomic) IBOutlet UIImageView *cimg;

@end
