//
//  TrafficViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 19..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "TrafficViewController.h"
#import "SWRevealViewController.h"
#import "MoneyData.h"
#import "TrafficTableViewCell.h"
#import "StartNViewController.h"
#import "DetailMViewController.h"
#import "AppDelegate.h"

@interface TrafficViewController ()

@end

@implementation TrafficViewController

@synthesize trafficTable;
@synthesize cTotal, cName, kTotal;

- (void)doTheThing:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    StartNViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"Start"];
    [self presentViewController:start animated:YES
                     completion:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"메뉴"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self.revealViewController
                                                                   action:@selector(revealToggle:)];
    self.tabBarController.navigationItem.rightBarButtonItem = rightButton;
    
    _barButton.target = self.revealViewController;
    _barButton.action = @selector(revealToggle:);
    
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"메인"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(doTheThing:)];
    self.tabBarController.navigationItem.leftBarButtonItem = leftButton;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    csum = 0;
    ksum = 0;
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    cName.text = app.segcon;
    cTotal.text = @"0";
    kTotal.text = @"0";
    
    fArray = [[NSArray alloc] init];
    [self downloadSData];
}

-(void) downloadSData {
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/money/mTable.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    NSMutableArray *tmpArray = [[NSMutableArray alloc] init];
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        MoneyData *data = [[MoneyData alloc] init];
        data.mnum = jsonElement[@"mnum"];
        data.tnum = jsonElement[@"tnum"];
        data.mcon = jsonElement[@"mcon"];
        data.mday = jsonElement[@"mday"];
        data.mcategory = jsonElement[@"mcategory"];
        data.mway = jsonElement[@"mway"];
        data.mname = jsonElement[@"mname"];
        data.money = jsonElement[@"money"];
        data.mcur = jsonElement[@"mcur"];
        
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];
        
        if ([data.tnum isEqualToString:app.themeNum]) {
            if ([data.mcon isEqualToString:app.segcon] && [data.mcategory isEqualToString:@"교통"]) {
                [tmpArray addObject:data];
            }
        }
    }
    
    fArray = tmpArray;
    
    
    [self.trafficTable reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [fArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"TrafficCell";
    
    TrafficTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (cell == nil) {
        cell = [[TrafficTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    MoneyData *md;
    md = fArray[indexPath.row];
    
    cell.trname.text = md.mname;
    cell.trmoney.text = md.money;
    cell.trcountry.text = md.mcon;
    
    if ([md.mway isEqualToString:@"현금"]) {
        cell.cimg.image = [UIImage imageNamed:@"cash.png"];
    }
    else if ([md.mway isEqualToString:@"카드"]) {
        cell.cimg.image = [UIImage imageNamed:@"card.png"];
    }
    
    
    float m = [md.money floatValue];
    float c = [md.mcur floatValue];
    
    csum = csum + m;
    
    int sum = m*c;
    ksum = ksum + sum;
    
    kTotal.text = [NSString stringWithFormat:@"%i", ksum];
    cTotal.text = [NSString stringWithFormat:@"%i", csum];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"TrafficDetail"]) {
        DetailMViewController *detailVC = segue.destinationViewController;
        NSIndexPath *indexPath = [self.trafficTable indexPathForSelectedRow];
        
        MoneyData *item;
        item = fArray[indexPath.row];
        detailVC.title = item.mname;
        detailVC.pickData = item;
    }
}


@end
