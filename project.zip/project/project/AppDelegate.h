//
//  AppDelegate.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 12..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@property (strong, nonatomic) NSString *themeNum;
@property (strong, nonatomic) NSString *cashc;
@property (strong, nonatomic) NSString *segcon;
@property (strong, nonatomic) NSString *categ;

@property (assign, nonatomic) BOOL onOff;
@property (assign, nonatomic) float per;
@property (strong, nonatomic) NSString *daybudg;

@end

