//
//  BSetViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 4..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BSetViewController : UIViewController <UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource> {
    NSArray * data1;
}

@property (strong, nonatomic) IBOutlet UILabel *bdate;
@property (strong, nonatomic) IBOutlet UILabel *budget;
@property (strong, nonatomic) IBOutlet UILabel *bcon;
@property (strong, nonatomic) IBOutlet UITextField *bset;

@property (strong, nonatomic) IBOutlet UIPickerView *percent;

@property (strong, nonatomic) IBOutlet UISwitch *onoff;


- (IBAction)budgetEdit:(UIButton *)sender;

- (IBAction)swichChange:(UISwitch *)sender;

- (BOOL)textFieldShouldReturn:(UITextField *)textField;

@end
