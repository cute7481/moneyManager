//
//  BSetViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 4..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "BSetViewController.h"
#import "SWRevealViewController.h"
#import "StartNViewController.h"
#import "AppDelegate.h"

@interface BSetViewController ()

@end

@implementation BSetViewController

@synthesize bdate, budget, bcon;
@synthesize bset;
@synthesize percent;
@synthesize onoff;

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    data1 = [[NSArray alloc] initWithObjects:@"90%~",
             @"80%~", @"70%~", @"60%~", @"50%~", nil];
}

- (void)doTheThing:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    StartNViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"Start"];
    [self presentViewController:start animated:YES
                     completion:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"메뉴"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self.revealViewController
                                                                   action:@selector(revealToggle:)];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    rightButton.target = self.revealViewController;
    rightButton.action = @selector(revealToggle:);
    
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"메인"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(doTheThing:)];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.bdate.text = [dateFormatter stringFromDate:[NSDate date]];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    bcon.text = app.segcon;
    budget.text = app.daybudg;
    
    if (self.onoff.isOn) {
        app.onOff = true;
    }
    else {
        app.onOff = false;
    }
}

- (IBAction)budgetEdit:(UIButton *)sender {
    budget.text = bset.text;
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    app.daybudg = budget.text;
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [data1 count];
}

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [data1 objectAtIndex:row];
}

- (IBAction)swichChange:(UISwitch *)sender {
    NSString* first = [data1 objectAtIndex:[self.percent selectedRowInComponent: 0]];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    
    if (self.onoff.isOn) {
        app.onOff = true;
        if ([first isEqualToString:@"90%~"]) {
            app.per = 0.90;
        }
        else if ([first isEqualToString:@"80%~"]) {
            app.per = 0.80;
        }
        else if ([first isEqualToString:@"70%~"]) {
            app.per = 0.70;
        }
        else if ([first isEqualToString:@"60%~"]) {
            app.per = 0.60;
        }
        else if ([first isEqualToString:@"50%~"]) {
            app.per = 0.50;
        }
    }
    else {
        app.onOff = false;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
