//
//  CardTableViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 3..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *cdname;
@property (strong, nonatomic) IBOutlet UILabel *cdmoney;
@property (strong, nonatomic) IBOutlet UILabel *cdcountry;

@property (strong, nonatomic) IBOutlet UIImageView *cdcatimg;

@end
