//
//  Chart.h
//  PIE
//
//  Created by SWUcomouter on 2016. 5. 28..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Chart : NSObject

@property (nonatomic, strong) NSString *one;
@property (nonatomic, strong) NSString *two;
@property (nonatomic, strong) NSString *three;
@property (nonatomic, strong) NSString *four;
@property (nonatomic, strong) NSString *five;

@end
