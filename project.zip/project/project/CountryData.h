//
//  CountryData.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CountryData : NSObject

@property (nonatomic, strong) NSString *tnum;
@property (nonatomic, strong) NSString *cstartd;
@property (nonatomic, strong) NSString *cfinishd;
@property (nonatomic, strong) NSString *ccountry;
@property (nonatomic, strong) NSString *ccur;
@property (nonatomic, strong) NSString *cflag;

@end
