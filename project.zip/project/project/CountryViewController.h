//
//  CountryViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ThemeData.h"

@interface CountryViewController : UIViewController
<UICollectionViewDelegate, UICollectionViewDataSource> {
    NSArray *fetchedAry;
}

@property (strong, nonatomic) IBOutlet UICollectionView *conCollection;

@property (strong, nonatomic) ThemeData *selectedData;

@end
