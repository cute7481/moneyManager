//
//  CountryViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "CountryViewController.h"
#import "CountryCollectionViewCell.h"
#import "AppDelegate.h"
#import "CountryData.h"
#import "SWRevealViewController.h"

@interface CountryViewController ()

@end

@implementation CountryViewController

@synthesize conCollection;
@synthesize selectedData;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    app.themeNum = selectedData.tnum;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    fetchedAry = [[NSArray alloc] init];
    [self downloadData];
}

-(void) downloadData {
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/country/cCollection.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    NSMutableArray *tmpArray = [[NSMutableArray alloc] init];
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        CountryData *nData = [[CountryData alloc] init];
        nData.tnum = jsonElement[@"tnum"];
        nData.cstartd = jsonElement[@"cstartd"];
        nData.cfinishd = jsonElement[@"cfinishd"];
        nData.ccountry = jsonElement[@"ccountry"];
        nData.ccur = jsonElement[@"ccur"];
        nData.cflag = jsonElement[@"cflag"];
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];
        if ([nData.tnum isEqualToString:app.themeNum]) {
            [tmpArray addObject:nData];
        }
    }
    
    fetchedAry = tmpArray;
    
    
    [self.conCollection reloadData];
}


// datasource and delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [fetchedAry count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"CountryCell";
    
    CountryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    //conImg, country, cdate
    CountryData *itemCon;
    itemCon = fetchedAry[indexPath.item];
    
    NSString *imgName = [NSString stringWithFormat:@"%@", itemCon.cflag];
    UIImage *img = [UIImage imageNamed:imgName];
    
    [[cell conImg]setImage:img];
    [[cell country]setText:itemCon.ccountry];
    
    //NSString *strd = [itemCon.cstartd stringByAppendingString:@" ~ "];
    //[[cell cdate]setText:[itemCon.cstartd stringByAppendingString:@" ~ "]];
    [[cell cdate]setText:itemCon.cstartd];
    [[cell cfdate]setText:[@"~" stringByAppendingString:itemCon.cfinishd]];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"toRevealView"]) {
        SWRevealViewController *swVC = [segue destinationViewController];
        
        UICollectionViewCell *cell = (UICollectionViewCell*)sender;
        NSIndexPath *indexPath = [self.conCollection indexPathForCell:cell];
        
        CountryData *cItem;
        cItem = fetchedAry[indexPath.item];
        swVC.title = cItem.ccountry;
        swVC.selectedD = cItem;
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];
        app.cashc = cItem.ccur;
        
        if ([cItem.ccountry isEqualToString:@"미국 USD"]) {
            app.segcon = @"USD";
        }
        else if ([cItem.ccountry isEqualToString:@"일본 JPY"]) {
            app.segcon = @"JPY";
        }
        else if ([cItem.ccountry isEqualToString:@"유럽연합 EUR"]) {
            app.segcon = @"EUR";
        }
        else if ([cItem.ccountry isEqualToString:@"중국 CNY"]) {
            app.segcon = @"CNY";
        }
        else if ([cItem.ccountry isEqualToString:@"영국 GBP"]) {
            app.segcon = @"GBP";
        }
        else if ([cItem.ccountry isEqualToString:@"캐나다 CAD"]) {
            app.segcon = @"CAD";
        }
        else if ([cItem.ccountry isEqualToString:@"호주 AUD"]) {
            app.segcon = @"AUD";
        }
        else if ([cItem.ccountry isEqualToString:@"뉴질랜드 NZD"]) {
            app.segcon = @"NZD";
        }
        else if ([cItem.ccountry isEqualToString:@"홍콩 HKD"]) {
            app.segcon = @"HKD";
        }
        else if ([cItem.ccountry isEqualToString:@"스웨덴 SEK"]) {
            app.segcon = @"SEK";
        }
        else if ([cItem.ccountry isEqualToString:@"덴마크 DKK"]) {
            app.segcon = @"DKK";
        }
        else if ([cItem.ccountry isEqualToString:@"노르웨이 NOK"]) {
            app.segcon = @"NOK";
        }
        else if ([cItem.ccountry isEqualToString:@"사우디 SAR"]) {
            app.segcon = @"SAR";
        }
        else if ([cItem.ccountry isEqualToString:@"쿠웨이트 KWD"]) {
            app.segcon = @"KWD";
        }
        else if ([cItem.ccountry isEqualToString:@"바레인 BHD"]) {
            app.segcon = @"BHD";
        }
        else if ([cItem.ccountry isEqualToString:@"아랍연방 AED"]) {
            app.segcon = @"AED";
        }
        else if ([cItem.ccountry isEqualToString:@"태국 THB"]) {
            app.segcon = @"THB";
        }
        else if ([cItem.ccountry isEqualToString:@"싱가포르 SGD"]) {
            app.segcon = @"SGD";
        }
        else if ([cItem.ccountry isEqualToString:@"인도네시아 IDR"]) {
            app.segcon = @"IDR";
        }
        else if ([cItem.ccountry isEqualToString:@"인도 INR"]) {
            app.segcon = @"INR";
        }
        else if ([cItem.ccountry isEqualToString:@"말레이지아 MYR"]) {
            app.segcon = @"MYR";
        }
        
        [self.navigationController setNavigationBarHidden:YES animated:YES];
    }
}


@end
