//
//  CurTableView.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 20..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "CurTableView.h"

@implementation CurTableView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
