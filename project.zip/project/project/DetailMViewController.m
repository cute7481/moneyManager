//
//  DetailMViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 4..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "DetailMViewController.h"

@interface DetailMViewController ()

@end

@implementation DetailMViewController

@synthesize dDate, dCategory, dName, dMoney, dCountry, dCurrency, dKorea;
@synthesize pickData;

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    dDate.text = pickData.mday;
    dCategory.text = pickData.mcategory;
    
    
    
    
    dName.text = pickData.mname;
    dMoney.text = pickData.money;
    dCountry.text = pickData.mcon;
    dCurrency.text = pickData.mcur;
    
    float m = [pickData.money floatValue];
    float c = [pickData.mcur floatValue];
    int sum = m*c;
    dKorea.text = [NSString stringWithFormat:@"%i", sum];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnDelete:(UIButton *)sender {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"정말 삭제 하시겠습니까?"
                                                        message:@"" delegate:self
                                              cancelButtonTitle:@"취소" otherButtonTitles:@"삭제", nil];
    [alertView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex==1) {
        NSString *no = pickData.mnum;
    
        NSLog(@"%@", no);
        
        NSString *rawStr = [NSString stringWithFormat:@"mnum=%@", no];
        NSData *data = [rawStr dataUsingEncoding:NSUTF8StringEncoding];
    
        NSURL *url = [NSURL URLWithString:@"http://localhost/~swucomputer/money/deleteMoney.php"];
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:data];
    
        NSURLResponse *response;
        NSError *err;
        NSData *responseData = [NSURLConnection sendSynchronousRequest:request
                                                     returningResponse:&response
                                                                 error:&err];
        NSString *responseString =[NSString stringWithUTF8String:[responseData bytes]];
        NSLog(@"%@", responseString);
        
        [self.navigationController popViewControllerAnimated:YES];
    }
}
    

@end
