//
//  EtcViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 19..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EtcViewController : UIViewController <UITableViewDataSource, UITableViewDelegate> {
    NSArray *fArray;
    int csum;
    int ksum;
}

@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButton;
@property (strong, nonatomic) IBOutlet UITableView *etcTable;

@property (strong, nonatomic) IBOutlet UILabel *cTotal;
@property (strong, nonatomic) IBOutlet UILabel *cName;
@property (strong, nonatomic) IBOutlet UILabel *kTotal;

@end
