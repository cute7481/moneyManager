//
//  FirstViewController.m
//  CHART2
//
//  Created by SWUcomouter on 2016. 6. 4..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//




//
//  SBCEViewController.m
//  SimpleBarChartExample
//
//  Created by Mohammed Islam on 1/17/14.
//  Copyright (c) 2014 KSI Technology. All rights reserved.
//

#import "FirstViewController.h"
#import "NSMutableArray+TTMutableArray.h"
#import "AppDelegate.h"
#import "MoneyData.h"
#import "SWRevealViewController.h"
#import "StartNViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

@synthesize setDate, country;
@synthesize pDate;

- (void)doTheThing:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    StartNViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"Start"];
    [self presentViewController:start animated:YES
                     completion:nil];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"메뉴"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self.revealViewController
                                                                   action:@selector(revealToggle:)];
    
    self.tabBarController.navigationItem.rightBarButtonItem = rightButton;
    
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"메인"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(doTheThing:)];
    self.tabBarController.navigationItem.leftBarButtonItem = leftButton;
    self.tabBarController.tabBar.barTintColor = [UIColor colorWithRed:153.0/225.0 green:160 blue:0 alpha:1];
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    self.setDate.text = @"전체";
    [self.pDate setHidden:YES];
    
    AppDelegate *app = [[UIApplication sharedApplication]delegate];
    self.country.text = app.segcon;
    
    _chart.incrementValue = 100;
    [self downloadSData];
}

-(void) downloadSData {
    _values = [[NSArray alloc] init];
    
    shop = 0;
    tour = 0;
    traf = 0;
    food = 0;
    lodge = 0;
    etc = 0;
    
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/money/mTable.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    //NSMutableArray *tmpArray = [[NSMutableArray alloc] init];
    
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        MoneyData *data = [[MoneyData alloc] init];
        data.mnum = jsonElement[@"mnum"];
        data.tnum = jsonElement[@"tnum"];
        data.mcon = jsonElement[@"mcon"];
        data.mday = jsonElement[@"mday"];
        data.mcategory = jsonElement[@"mcategory"];
        data.mway = jsonElement[@"mway"];
        data.mname = jsonElement[@"mname"];
        data.money = jsonElement[@"money"];
        data.mcur = jsonElement[@"mcur"];
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];
        
        if ([data.mcon isEqualToString:app.segcon]) {
            if ([data.mcategory isEqualToString:@"쇼핑"]) {
                shop += [data.money floatValue];
            }
            else if ([data.mcategory isEqualToString:@"관광"]) {
                tour = tour + [data.money floatValue];
            }
            else if ([data.mcategory isEqualToString:@"교통"]) {
                traf = traf + [data.money floatValue];
            }
            else if ([data.mcategory isEqualToString:@"음식"]) {
                food = food + [data.money floatValue];
            }
            else if ([data.mcategory isEqualToString:@"숙박"]) {
                lodge = lodge + [data.money floatValue];
            }
            else if ([data.mcategory isEqualToString:@"기타"]) {
                etc = etc + [data.money floatValue];
            }
        }
    }
    
    NSArray *totAry = [[NSArray alloc]initWithObjects:
                       [NSNumber numberWithInt:shop], [NSNumber numberWithInt:tour],
                       [NSNumber numberWithInt:traf], [NSNumber numberWithInt:food],
                       [NSNumber numberWithInt:lodge], [NSNumber numberWithInt:etc], nil];
    
    _values = totAry;
    
    [_chart reloadData];
}

- (void)loadView {
    [super loadView];
    
    max = 0;
    
    // 통계 값 설정
    
    //_values	= [[NSArray alloc]initWithObjects:@12, @5, @23.5, @7.5, @20, @8.6, nil];
    _category = [[NSArray alloc]initWithObjects:@"쇼핑",@"관광", @"교통",@"음식",@"숙박", @"etc", nil];
    
    _barColors = @[[UIColor blueColor], [UIColor cyanColor],[UIColor magentaColor] ,
                   [UIColor orangeColor], [UIColor purpleColor], [UIColor greenColor]];
    
    _currentBarColor = 3;
    _maxBarColor = 4;
    
    CGRect chartFrame = CGRectMake(0.0, 0.0, 270.0, 270.0);
    _chart = [[SimpleBarChart alloc] initWithFrame:chartFrame];
    
    //차트 위치 변경
    _chart.center = CGPointMake(self.view.frame.size.width / 2.0, self.view.frame.size.height / 2.6);
    
    _chart.delegate	= self;
    _chart.dataSource = self;
    
    _chart.animationDuration = 1.0;
    
    _chart.barShadowOffset = CGSizeMake(3.0, 1.0); // 그림자
    _chart.barShadowColor = [UIColor grayColor];
    _chart.barShadowAlpha = 0.5;
    _chart.barShadowRadius = 1.0;
    
    _chart.barWidth	= 25.0;
    _chart.xLabelType = SimpleBarChartXLabelTypeVerticle;
    
    _chart.incrementValue = 100;
    
    _chart.barTextType = SimpleBarChartBarTextTypeTop;
    _chart.barTextColor	= [UIColor whiteColor];
    _chart.gridColor = [UIColor whiteColor];
    
    [self.view addSubview:_chart];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    pDate.transform = CGAffineTransformMake(0.65, 0, 0, 0.65, 0, 0 );
}

#pragma mark SimpleBarChartDataSource

// bar 개수
- (NSUInteger)numberOfBarsInBarChart:(SimpleBarChart *)barChart {
    return _values.count;
}

// 각자 바 크기
- (CGFloat)barChart:(SimpleBarChart *)barChart valueForBarAtIndex:(NSUInteger)index {
    return [[_values objectAtIndex:index] floatValue];
}

// 각 인덱스 바의 텍스트
- (NSString *)barChart:(SimpleBarChart *)barChart textForBarAtIndex:(NSUInteger)index {
    return [[_values objectAtIndex:index] stringValue];
}

// 각 차트 항목 라벨 ex. 월별 카테고리별
- (NSString *)barChart:(SimpleBarChart *)barChart xLabelForBarAtIndex:(NSUInteger)index {
    return [_category objectAtIndex:index];
    // [[_values objectAtIndex:index] stringValue];
}

// 색깔
- (UIColor *)barChart:(SimpleBarChart *)barChart colorForBarAtIndex:(NSUInteger)index {
    /*
     for(int i=0; i <_values.count; i++){
     if( _values[max] <_values[i]){
     max = i;
     }
     }
     */
    // return [_barColors objectAtIndex:_maxBarColor];
    
    return [_barColors objectAtIndex:_currentBarColor];
}

- (IBAction)totalShow:(UIButton *)sender {
    self.setDate.text = @"전체";
    _chart.incrementValue = 100;
    [self downloadSData];
}

- (IBAction)dpickerShow:(UIButton *)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    setDate.text = [dateFormatter stringFromDate: pDate.date];
    
    if ([pDate isHidden]) {
        [pDate setHidden:NO];
        _chart.incrementValue = 10;
        [sender setTitle:@"날짜 숨기기" forState:UIControlStateNormal];
    }
    else {
        [pDate setHidden:YES];
        [sender setTitle:@"날짜 선택" forState:UIControlStateNormal];
    }
    
    [self downloadSData2];
}

- (IBAction)dateChanged:(UIDatePicker *)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    setDate.text = [dateFormatter stringFromDate: pDate.date];
    
    _chart.incrementValue = 10;
    [self downloadSData2];
}

-(void) downloadSData2 {
    _values = [[NSArray alloc] init];
    
    shop = 0;
    tour = 0;
    traf = 0;
    food = 0;
    lodge = 0;
    etc = 0;
    
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/money/mTable.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    //NSMutableArray *tmpArray = [[NSMutableArray alloc] init];
    
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        MoneyData *data = [[MoneyData alloc] init];
        data.mnum = jsonElement[@"mnum"];
        data.tnum = jsonElement[@"tnum"];
        data.mcon = jsonElement[@"mcon"];
        data.mday = jsonElement[@"mday"];
        data.mcategory = jsonElement[@"mcategory"];
        data.mway = jsonElement[@"mway"];
        data.mname = jsonElement[@"mname"];
        data.money = jsonElement[@"money"];
        data.mcur = jsonElement[@"mcur"];
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];
        
        if ([data.mcon isEqualToString:app.segcon]) {
            if ([data.mday isEqualToString:setDate.text]) {
                if ([data.mcategory isEqualToString:@"쇼핑"]) {
                    shop += [data.money floatValue];
                }
                else if ([data.mcategory isEqualToString:@"관광"]) {
                    tour = tour + [data.money floatValue];
                }
                else if ([data.mcategory isEqualToString:@"교통"]) {
                    traf = traf + [data.money floatValue];
                }
                else if ([data.mcategory isEqualToString:@"음식"]) {
                    food = food + [data.money floatValue];
                }
                else if ([data.mcategory isEqualToString:@"숙박"]) {
                    lodge = lodge + [data.money floatValue];
                }
                else if ([data.mcategory isEqualToString:@"기타"]) {
                    etc = etc + [data.money floatValue];
                }
            }
        }
    }
    
    NSArray *totAry = [[NSArray alloc]initWithObjects:
                       [NSNumber numberWithInt:shop], [NSNumber numberWithInt:tour],
                       [NSNumber numberWithInt:traf], [NSNumber numberWithInt:food],
                       [NSNumber numberWithInt:lodge], [NSNumber numberWithInt:etc], nil];
    
    _values = totAry;
    
    [_chart reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end


