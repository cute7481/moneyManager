//
//  InsertMViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InsertMViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *mdate;

@property (strong, nonatomic) IBOutlet UITextField *mName;

@property (strong, nonatomic) IBOutlet UISegmentedControl *segCat;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segCC;

@property (strong, nonatomic) IBOutlet UITextField *spendM;
@property (strong, nonatomic) IBOutlet UILabel *whatcur;

@property (strong, nonatomic) IBOutlet UIView *writeCurV;
@property (strong, nonatomic) IBOutlet UITextField *mcurText;

@property (strong, nonatomic) IBOutlet UILabel *moneyCur;


- (IBAction)mdateChange:(UIButton *)sender;

- (IBAction)categorySet:(UISegmentedControl *)sender;
- (IBAction)waySet:(UISegmentedControl *)sender;

- (IBAction)mcashCur:(UIButton *)sender;
- (IBAction)mcardCur:(UIButton *)sender;

- (IBAction)mwriteCur:(UIButton *)sender;
- (IBAction)mwfinish:(UIButton *)sender;

- (BOOL)textFieldShouldReturn:(UITextField *)textField;

@end
