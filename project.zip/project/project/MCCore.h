//
//  MCCore.h
//  MCCore
//
//  Created by Vinícius Rodrigues on 22/11/2013.
//  Copyright (c) 2013 MyAppControls. All rights reserved.
//

#import <Foundation/Foundation.h>

// util
#import "MCUtil.h"

// custom layers
#import "MCNewCustomLayer.h"
#import "MCSliceLayer.h"

//custom views
#import "MCNewCustomLayeredView.h"