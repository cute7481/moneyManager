//
//  MoneyData.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoneyData : NSObject

@property (nonatomic, strong) NSString *mnum;
@property (nonatomic, strong) NSString *tnum;
@property (nonatomic, strong) NSString *mcon;
@property (nonatomic, strong) NSString *mday;
@property (nonatomic, strong) NSString *mcategory;
@property (nonatomic, strong) NSString *mway;
@property (nonatomic, strong) NSString *mname;
@property (nonatomic, strong) NSString *money;
@property (nonatomic, strong) NSString *mcur;

@end
