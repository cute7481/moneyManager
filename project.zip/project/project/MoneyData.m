//
//  MoneyData.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 23..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "MoneyData.h"

@implementation MoneyData

@end
