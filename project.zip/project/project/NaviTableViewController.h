//
//  NaviTableViewController.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 16..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NaviTableViewController : UITableViewController

@end
