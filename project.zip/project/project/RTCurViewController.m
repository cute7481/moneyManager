//
//  RTCurViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 20..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "RTCurViewController.h"
#import "RTTableViewCell.h"

@interface RTCurViewController ()

@end

@implementation RTCurViewController {
    NSArray *countryAr;
    NSArray *countryImg;
    NSDate *sDate;
    
    NSArray *nation;
}

@synthesize refDate;
@synthesize curTable;

- (void)viewDidLoad {
    [super viewDidLoad];
    countryAr = [[NSArray alloc] initWithObjects:
                 @"미국 USD", @"일본 JPY", @"유럽연합 EUR", @"중국 CNY", @"영국 GBP",
                 @"스위스 CHF", @"캐나다 CAD", @"호주 AUD", @"뉴질랜드 NZD", @"홍콩 HKD",
                 @"스웨덴 SEK", @"덴마크 DKK", @"노르웨이 NOK", @"사우디 SAR", @"쿠웨이트 KWD",
                 @"바레인 BHD", @"아랍연방 AED", @"태국 THB", @"싱가포르 SGD", @"인도네시아 IDR",
                 @"인도 INR", @"말레이지아 MYR", nil];
    
    
    //erase
    /*
    France = [UIImage imageNamed:@"France Flag.png"]; //유럽연합
    Germany = [UIImage imageNamed:@"Germany Flag.png"];
    Ireland = [UIImage imageNamed:@"Ireland Flag.png"];//유럽연합
    Italy = [UIImage imageNamed:@"Italy Flag.png"]; //유럽연합
    Philippines = [UIImage imageNamed:@"Philippines Flag.png"];
    Spain = [UIImage imageNamed:@"Spain Flag.png"]; //유럽연합
    Taiwan = [UIImage imageNamed:@"Taiwan Flag.png"];
    Turkey = [UIImage imageNamed:@"Turkey Flag.png"];
    Vietnam = [UIImage imageNamed:@"Vietnam Flag.png"];
    */
    
    UnitedStates = [UIImage imageNamed:@"United States Flag.png"];
    Japan  = [UIImage imageNamed:@"Japan Flag.png"];
    EuropeanUnion = [UIImage imageNamed:@"European Union flag.jpg"];
    China = [UIImage imageNamed:@"China Flag.png"];
    UnitedKingdom = [UIImage imageNamed:@"United Kingdom flag.png"];
    
    Switzerland = [UIImage imageNamed:@"Switzerlandflag.png"];
    Canada = [UIImage imageNamed:@"Canada Flag.png"];
    Australia = [UIImage imageNamed:@"Australia Flag.png"];
    NewZealand = [UIImage imageNamed:@"New Zealand Flag.png"];
    HongKong = [UIImage imageNamed:@"Hong Kong Flag.png"];
    
    Sweden = [UIImage imageNamed:@"Swedenflag.png"];
    Denmark = [UIImage imageNamed:@"Denmark flag.png"];
    Norway = [UIImage imageNamed:@"Norway Flag.png"];
    SaudiArabian = [UIImage imageNamed:@"Saudi Arabian flag.jpg"];
    Kuwait = [UIImage imageNamed:@"Kuwait flag.png"];
    
    Bahrain = [UIImage imageNamed:@"Bahrain flag.png"];
    UnitedArabEmirates = [UIImage imageNamed:@"United Arab Emirates flag.png"];
    Thailand = [UIImage imageNamed:@"Thailandflag.png"];
    Singapore = [UIImage imageNamed:@"Singapore Flag.png"];
    Indonesia = [UIImage imageNamed:@"Indonesia flag.png"];
    
    India = [UIImage imageNamed:@"India Flag.png"];
    Malaysia = [UIImage imageNamed:@"Malaysia Flag.png"];
    
    countryImg = [[NSArray alloc] initWithObjects:
                  UnitedStates, Japan, EuropeanUnion, China, UnitedKingdom,
                  Switzerland, Canada, Australia, NewZealand, HongKong,
                  Sweden, Denmark, Norway, SaudiArabian, Kuwait,
                  Bahrain, UnitedArabEmirates, Thailand, Singapore, Indonesia,
                  India, Malaysia, nil];
    
    sDate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy.MM.dd h:mm:ss a"];
    refDate.text = [formatter stringFromDate:sDate];
    
    
    nation = [[NSArray alloc] initWithObjects:
              @"http://localhost/~swucomputer/cur/USD.php", @"http://localhost/~swucomputer/cur/JPY.php",
              @"http://localhost/~swucomputer/cur/EUR.php", @"http://localhost/~swucomputer/cur/CNY.php",
              @"http://localhost/~swucomputer/cur/GBP.php", @"http://localhost/~swucomputer/cur/CHF.php",
              @"http://localhost/~swucomputer/cur/CAD.php", @"http://localhost/~swucomputer/cur/AUD.php",
              @"http://localhost/~swucomputer/cur/NZD.php", @"http://localhost/~swucomputer/cur/HKD.php",
              @"http://localhost/~swucomputer/cur/SEK.php", @"http://localhost/~swucomputer/cur/DKK.php",
              @"http://localhost/~swucomputer/cur/NOK.php", @"http://localhost/~swucomputer/cur/SAR.php",
              @"http://localhost/~swucomputer/cur/KWD.php", @"http://localhost/~swucomputer/cur/BHD.php",
              @"http://localhost/~swucomputer/cur/AED.php", @"http://localhost/~swucomputer/cur/THB.php",
              @"http://localhost/~swucomputer/cur/SGD.php", @"http://localhost/~swucomputer/cur/IDR.php",
              @"http://localhost/~swucomputer/cur/INR.php", @"http://localhost/~swucomputer/cur/MYR.php", nil];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [countryAr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"CurrencyCell";
    
    RTTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (cell == nil) {
        cell = [[RTTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    cell.cname.text = [countryAr objectAtIndex:indexPath.row];
    //cell.detailTextLabel.text = @"hi";
    cell.cImage.image = [countryImg objectAtIndex:indexPath.row];
    
    NSString *gUrl = [nation objectAtIndex:indexPath.row];
    
    NSString *message;
    NSURL *urlString = [NSURL URLWithString:gUrl];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:urlString];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSError *err = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    NSData *responseData = [NSURLConnection sendSynchronousRequest:urlRequest
                                                 returningResponse:&response
                                                             error:&err];
    NSString *responseString = [[NSString alloc] initWithBytes:[responseData bytes]
                                                        length:[responseData length]
                                                      encoding:NSUTF8StringEncoding];
    message = responseString;
    //NSLog(@"%@", responseString);
    
    cell.ccur.text = message;
    
    return cell;
}

- (IBAction)refreshTable:(UIButton *)sender {
    sDate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy.MM.dd h:mm:ss a"];
    refDate.text = [formatter stringFromDate:sDate];
    
    [self.curTable reloadData];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
