//
//  SecondViewController.h
//  CHART2
//
//  Created by SWUcomouter on 2016. 6. 4..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "MCPieChartView.h"
#import "DLPieChart.h"

@interface SecondViewController : UIViewController <MCPieChartViewDataSource, MCPieChartViewDelegate> {
    
    NSMutableArray *values;
    NSMutableArray *labels;
    NSMutableArray *ccolors;
    BOOL inserting;
    
    int sum;
    int ksum;
    
    NSString *coun;
}

@property (strong, nonatomic) IBOutlet MCPieChartView *pieChartView;

@property (strong, nonatomic) IBOutlet UIScrollView *scroll;


@end
