//
//  SecondViewController.m
//  CHART2
//
//  Created by SWUcomouter on 2016. 6. 4..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//



//
//  ViewController.m
//  PieChartSample
//
//  Created by Vinícius Rodrigues on 26/06/2014.
//  Copyright (c) 2014 MyAppControls. All rights reserved.
//

#import "SecondViewController.h"
#import "MoneyData.h"
#import "AppDelegate.h"
#import "SWRevealViewController.h"
#import "StartNViewController.h"

#define OFFSET 20

@interface SecondViewController ()

@end

@implementation SecondViewController

@synthesize pieChartView;
@synthesize scroll;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 배열로 설정
    values = [[NSMutableArray alloc] init];
    labels = [[NSMutableArray alloc] init];
    ccolors = [[NSMutableArray alloc] init];
    
    //pie 만들기
    self.pieChartView.dataSource = self;
    self.pieChartView.delegate = self;
    self.pieChartView.animationDuration = 0.5;
    self.pieChartView.sliceColor = [MCUtil flatPomegranateColor];
    self.pieChartView.borderColor = [MCUtil flatAmethystColor];
    self.pieChartView.selectedSliceColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.textColor = [MCUtil flatSunFlowerColor];
    self.pieChartView.selectedTextColor = [MCUtil flatWetAsphaltColor];
    self.pieChartView.borderPercentage = 0.02; // 슬라이스 두께
}

- (void)legendClicked:(id)sender {
    //NSString *btnSelect = lbl.text; // = [NSString stringWithFormat:@"%@",[values objectAtIndex:]];
}


- (void)makelabels {
    
    CGFloat legendX,legendY,legendWidth, legendHeight;
    
    legendX = OFFSET*2;
    legendY = OFFSET*18;
    legendWidth = 500;
    legendHeight = 500 - OFFSET;
    
    //labels
    int y = 5;
    for (int i = 0;i < values.count;i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        // CGRectMake는 CGRect를 쉽게 만들기 위해서 애플이 제공하는 함수로서, 너비와 높이와 함께 x,y위치를 명시하기만 하면된다.
        btn.frame = CGRectMake(5, y, 30, 30);
        btn.tag = i;
        [btn addTarget:self action:@selector(legendClicked:) forControlEvents:UIControlEventTouchUpInside];
        btn.backgroundColor = [ccolors objectAtIndex:i]; //[_barColors objectAtIndex:i];
        
        //[legendsScrollView addSubview:btn];
        [scroll addSubview:btn];
        
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(40, y, legendWidth-OFFSET*2, 30)];
        
        // 각 차트 표시 부분 (lbl.text = @"label23")
        lbl.text = [NSString stringWithFormat:@"%@",[labels objectAtIndex:i]];
        lbl.backgroundColor = [UIColor clearColor];
        [lbl setAdjustsFontSizeToFitWidth:YES];
        
        //[legendsScrollView addSubview:lbl];
        [scroll addSubview:lbl];
        
        y += lbl.frame.size.height+5;
    }
}

- (void)doTheThing:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    StartNViewController *start = [storyboard
                                   instantiateViewControllerWithIdentifier:@"Start"];
    [self presentViewController:start animated:YES
                     completion:nil];
    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"메뉴"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self.revealViewController
                                                                   action:@selector(revealToggle:)];
    
    self.tabBarController.navigationItem.rightBarButtonItem = rightButton;
    
    [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"메인"
                                                                   style:UIBarButtonItemStylePlain
                                                                  target:self
                                                                  action:@selector(doTheThing:)];
    self.tabBarController.navigationItem.leftBarButtonItem = leftButton;
    
    
    values = [[NSMutableArray alloc] init];
    labels = [[NSMutableArray alloc] init];
    ccolors = [[NSMutableArray alloc] init];
    
    [self downloadSData];
    
    [self makelabels];
}

-(void) downloadSData {
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/money/mTable.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    NSMutableArray *conCheck = [[NSMutableArray alloc] init];
    NSMutableArray *conMoney = [[NSMutableArray alloc] init];
    NSMutableArray *conColor = [[NSMutableArray alloc] init];
    
    NSInteger aryNum;
    float sSum;
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        MoneyData *data = [[MoneyData alloc] init];
        data.mnum = jsonElement[@"mnum"];
        data.tnum = jsonElement[@"tnum"];
        data.mcon = jsonElement[@"mcon"];
        data.mday = jsonElement[@"mday"];
        data.mcategory = jsonElement[@"mcategory"];
        data.mway = jsonElement[@"mway"];
        data.mname = jsonElement[@"mname"];
        data.money = jsonElement[@"money"];
        data.mcur = jsonElement[@"mcur"];
        
        AppDelegate *app = [[UIApplication sharedApplication]delegate];

        if ([conCheck containsObject:data.mcon]) {
            aryNum = [conCheck indexOfObject:data.mcon];
            sSum = [[conMoney objectAtIndex:aryNum]floatValue];
            sSum += [data.money floatValue];
            [conMoney removeObjectAtIndex:aryNum];
            [conMoney insertObject:[NSNumber numberWithFloat:sSum] atIndex:aryNum];
        }
        else {
            CGFloat hue = ( arc4random() % 256 / 256.0 );  //  0.0 to 1.0
            CGFloat saturation = ( arc4random() % 128 / 256.0 ) + 0.5;  //  0.5 to 1.0, away from white
            CGFloat brightness = ( arc4random() % 128 / 256.0 ) + 0.5;  //  0.5 to 1.0, away from black
            UIColor *rand = [UIColor colorWithHue:hue saturation:saturation brightness:brightness alpha:1];
            
            [conCheck addObject:data.mcon];
            [conMoney addObject:data.money];
            [conColor addObject:rand];
        }
    }
    
    values = conMoney;
    labels = conCheck;
    ccolors = conColor;
    
    [self.pieChartView reloadData];
}

- (UIColor *)pieChartView:(MCPieChartView *)pieChartView colorForSliceAtIndex:(NSInteger)index {
    return [ccolors objectAtIndex:index];
}

- (UIColor *)pieChartView:(MCPieChartView *)pieChartView colorForTextAtIndex:(NSInteger)index {
    return [UIColor whiteColor];
}

- (NSInteger)numberOfSlicesInPieChartView:(MCPieChartView *)pieChartView {
    return [values count];
}


/* // 인덱스는 0번부터 1번인덱스인 경우 이미지 지정하기
 - (UIImage*)pieChartView:(MCPieChartView *)pieChartView imageForSliceAtIndex:(NSInteger)index
 {
 if (index == 1) {
 return [UIImage imageNamed:@"texture-yellow-dots"];
 }
 
 return nil;
 }
 */

//  인덱스의 text 색 지정
//- (UIColor*)pieChartView:(MCPieChartView *)pieChartView colorForTextAtIndex:(NSInteger)index
//{
//    if (index == 0) { // 0번 blackcolor로
//        return [UIColor blackColor];
//    }
//    return [UIColor lightGrayColor]; //
//}

- (CGFloat)pieChartView:(MCPieChartView *)pieChartView valueForSliceAtIndex:(NSInteger)index {
    return [[values objectAtIndex:index] floatValue];
}

@end
