//
//  StartNViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 4..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "StartNViewController.h"

@interface StartNViewController ()

@end

@implementation StartNViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:50 green:187 blue:65 alpha:1];
    //self.tabBarController.tabBar.barTintColor = [UIColor colorWithRed:153.0/225.0 green:160 blue:0 alpha:1];
    self.tabBarController.tabBar.barTintColor = [UIColor colorWithRed:153.0/225.0 green:160 blue:0 alpha:1];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
