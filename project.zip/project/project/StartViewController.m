//
//  StartViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 4..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "StartViewController.h"

@interface StartViewController ()

@end

@implementation StartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //UIView *statusBarView = [[UIView alloc]initWithFrame:CGRectMake(0, -20, 500, 64)];
    //statusBarView.backgroundColor = [UIColor colorWithRed:153.0/225.0 green:204 blue:255 alpha:1];
    
    //[self.navigationController.navigationBar addSubview:statusBarView];
    
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:153.0/225.0 green:160 blue:0 alpha:1];

      //self.tabBarController.tabBar.barTintColor = [UIColor colorWithRed:153.0/225.0 green:160 blue:0 alpha:1];
     
    [[UITabBar appearance]setTintColor:[UIColor blackColor]];
    [[UITabBar appearance]setBarTintColor:[UIColor colorWithRed:153 green:204 blue:255 alpha:1]];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
