//
//  ThemeViewController.m
//  project
//
//  Created by SWUCOMPUTER on 2016. 5. 22..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import "ThemeViewController.h"
#import "ThemeCollectionViewCell.h"
#import "ThemeData.h"
#import "CountryViewController.h"

@interface ThemeViewController ()

@end

@implementation ThemeViewController

@synthesize myCollectionView;

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    fetchedArray = [[NSArray alloc] init];
    [self downloadDataFromServer];
}

-(void) downloadDataFromServer {
    NSURL *jsonFileUrl = [NSURL URLWithString:@"http://localhost/~swucomputer/theme/tCollection.php"];
    NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:jsonFileUrl];
    [NSURLConnection connectionWithRequest:urlRequest delegate:self];
    
    NSData *fromServerData = [[NSData alloc] init];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *response = nil;
    
    fromServerData = [NSURLConnection sendSynchronousRequest:urlRequest
                                           returningResponse:&response
                                                       error:&error];
    
    NSMutableArray *tempArray = [[NSMutableArray alloc] init];
    NSArray *jsonArray = [NSJSONSerialization JSONObjectWithData:fromServerData
                                                         options:NSJSONReadingAllowFragments
                                                           error:&error];
    
    for (int i = 0; i < jsonArray.count; i++) {
        NSDictionary *jsonElement = jsonArray[i];
        
        ThemeData *newData = [[ThemeData alloc] init];
        newData.tnum = jsonElement[@"tnum"];
        newData.tstartd = jsonElement[@"tstartd"];
        newData.tfinishd = jsonElement[@"tfinishd"];
        newData.timage = jsonElement[@"timage"];
        newData.tname = jsonElement[@"tname"];
        
        [tempArray addObject:newData];
    }
    
    fetchedArray = tempArray;
    [self.myCollectionView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //[[self.myCollectionView]setDataSource:self];
    //[[self.myCollectionView]setDelegate:self];
    
    //aryImg = [[NSArray alloc]initWithObjects:@"", @"", @"", @"", @"", nil];
    //aryThm = [[NSArray alloc]initWithObjects:@"1", @"2", @"3", @"4", @"5", nil];
    //aryDate = [[NSArray alloc]initWithObjects:@"1", @"2", @"3", @"4", @"5", nil];
}

// datasource and delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [fetchedArray count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"ThemeCell";
    
    ThemeCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    ThemeData *tItem;
    tItem = fetchedArray[indexPath.item];
    
    NSString *imageName = [NSString stringWithFormat:@"%@", tItem.timage];
    UIImage *image = [UIImage imageNamed:imageName];
    
    if (tItem.timage != nil) {
        NSString *urlString = @"http://localhost/~swucomputer/theme/image/";
        imageName = [urlString stringByAppendingString:imageName];
        
        NSURL *url = [[NSURL alloc] initWithString:imageName];
        image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
    }
    
    [[cell themeImg]setImage:image];
    [[cell theme]setText:tItem.tname];
    
    NSString *sd = [tItem.tstartd stringByAppendingString:@" ~ "];
    [[cell themeDate]setText:[sd stringByAppendingString:tItem.tfinishd]];
    
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"toCountryView"]) {
        
        
        CountryViewController *VC = [segue destinationViewController];
        
        UICollectionViewCell *cell = (UICollectionViewCell*)sender;
        NSIndexPath *indexPath = [self.myCollectionView indexPathForCell:cell];
        
        ThemeData *dItem;
        dItem = fetchedArray[indexPath.item];
        VC.title = dItem.tname;
        VC.selectedData = dItem;
    }
}


@end
