//
//  ThirdViewController.h
//  CHART2
//
//  Created by SWUcomouter on 2016. 6. 4..
//  Copyright (c) 2016년 SWUcomouter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCPieChartView.h"
#import "DLPieChart.h"
@interface ThirdViewController : UIViewController <MCPieChartViewDataSource, MCPieChartViewDelegate>{
    
    NSArray *values;
    NSArray *labels;
    
    NSMutableArray *ccolors;
    
    float cardSum;
    float cashSum;
}

@property (strong, nonatomic) IBOutlet MCPieChartView *pieChartView;

@property (strong, nonatomic) IBOutlet UIScrollView *scroll;

@end
