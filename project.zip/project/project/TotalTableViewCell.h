//
//  TotalTableViewCell.h
//  project
//
//  Created by SWUCOMPUTER on 2016. 6. 3..
//  Copyright (c) 2016년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TotalTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *tname;
@property (strong, nonatomic) IBOutlet UILabel *tmoney;
@property (strong, nonatomic) IBOutlet UILabel *tcontry;

@property (strong, nonatomic) IBOutlet UIImageView *tcatimg;

@end
